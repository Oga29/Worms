# Worms
Worms game project for Physics 2

## CONTROLS

A: Left

D: Right

W: Jump

TAB: Swich weapon

SPACE: Shoot

Mouse: Aim 

## Available weapons

Shotgun

Airstrike

Grenade


## DEBUG MODE

F1: Debug mode

With debug mode on

F2: Variable Delta Time

F3: Fixed Delta Time

F4: Control Delta Time

F5: Integrator Implicit Euler

F6: Integrator Symplectic Euler

F7: Integrator Verlet

1: 15FPS 

2: 30FPS 

3: 60FPS 

4: 144FPS

Arrows: Control the wind velocities (x and y)

B: Kill all the blue worms

R: Kill all the red wormsF5

## Bibliography

all assets has been taken from Sprites Resource website in Worms Armageddon section

(https://www.spriters-resource.com/pc_computer/wormsgeddon/)
